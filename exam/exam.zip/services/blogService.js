const Blog = require("../models/Blog");
const User = require("../models/User");

async function getAll() {
  return await Blog.find({}).lean();
}

async function getById(id) {
    return await  Blog.findById(id).lean();
};
async function create(data) {
    console.log(data)
  return await Blog.create(data);

}

async function getLastTree() {
  return await Blog.find().limit(3).lean();
}

module.exports = {
  create,
  getLastTree,
  getAll,
  getById,
};
